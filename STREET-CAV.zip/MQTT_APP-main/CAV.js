let mqtt = require("mqtt");
var client = mqtt.connect("mqtt://127.0.0.1:1883");
let timer;

/*
 ~~~ CAV SIMULATION APP ~~~
*/

// Connecting the MQTT client of the CAV
client.on("connect", function() {

    // Subscribing to the "CAV/command" topic - The CAV will recieve message over MQTT on this topic name from the CSE (which has passed through the IPE to deserialize the message content)
    client.subscribe('CAV/command');
});

// Message handling of MQTT clients - Anytime a message is sent to our subscribed topics this function is triggered
// We recieve the Topic and the Payload
client.on('message', (topic, payload)=> {
    
    // Checking the topic is correct
    if(topic === 'CAV/command'){

        // Checking the payload of the deserliazed content which has passed through the IPE
        // The respective methods are called
        if(payload.toString() === 'stop'){
            stop();
        }
       if(payload.toString() === 'start'){
            startCav();
       }

    }
})

/*

 Note: The client.publish("xxxxxxx") in the functions below
 Where xxxxxxx = a topic that the IPE is subscribed to, allowing it to recieve messages from the CAV. 
 i.e, the CAV publishes messages over MQTT to the IPE. The IPE is subscribed to these topics that the CAV is publishing to. The IPE will convert these messages to CSE compliant objects

 */

// CAV simulation function
// Generates random lat/lng positions and publises them over MQTT to the IPE
// Generates a response message and publishes it over MQTT to the IPE
function startCav() {
    console.log("Starting cav");
    client.publish('CAV/response', JSON.stringify({"response": "STARTING CAV"}))
    timer = setInterval(() => {
        var randomLat = (53.3409 + (Math.random() - 0.5) * 0.1);
        var randomLng = (-6.2625 + (Math.random() - 0.5) * 0.1);
        console.log("Latitude: " + randomLat);
        console.log("Longitude: " + randomLng);
        client.publish('CAV/latlng', JSON.stringify({"lat": randomLat, "lng": randomLng}));
    },  5000);
}

// CAV stop function
// Stops the generation of random lat/lng positions
// Generates a response message and publishes it over MQTT to the IPE
function stop(){
    client.publish('CAV/response', JSON.stringify({"response": "STOPPING CAV"}))
    console.log("Stopping cav");
    clearInterval(timer);
}