/* 



EXPERIMENTAL VERSION OF V2X APP - Do not run - This is a HTTP version and has not been developed to work with the front end


*/

let baseUrl = "http://127.0.0.1:8080/cse-in";
const express = require("express");
const { createServer } = require('http');
const { Server } = require('socket.io');


const httpServer = createServer();
const io = new Server(httpServer, {
  cors: {
    origin: "http://localhost:4200"
  }
});
const app = express();
const server = createServer(app);



app.listen(3000);
app.use(express.json());


app.post('/', function(req, res){
    let hl = req.header('Content-Length');
    let ct = req.header('Content-Type');
    let rID = req.header('X-M2M-RI');
    console.log(req.body);
    res.status(200).set('X-M2M-RSC', '2000').set('X-M2M-RI', rID).send();
    io.emit('data', req.body["m2m:sgn"]["nev"]["rep"]["m2m:cin"]["con"]);
})


io.listen(3001, () => {
    console.log('server running at http://localhost:3001');
  });




registerAE("Temp").then(data => {
    //console.log(data);
    registerAcp().then(data => {
      //  console.log(data);
        applyAcp().then(data => {
           // console.log(data);
            registerGroup().then(data => {
//console.log(data);
            });
        });
    });
});

// registerGroup().then(data => {
//     console.log(data);
// });

// getFopt().then(data => {
//     console.log(data['m2m:agr']['m2m:rsp'][0]['pc']);
// })

function setHeaders(contentType, originator) {

    return {
        'X-M2M-Origin': originator,
        'X-M2M-RI': '1234',
        'X-M2M-RVI': '3',
        'Accept': 'application/json',
        'Content-Type': contentType
    }
}




async function postData(url = "", headersOptions, data = {}) {
    const response = await fetch(url, {
        method: 'POST',
        headers: headersOptions,
        body: JSON.stringify(data),
    });
    return response.json();
}

async function putData(url="", headersOptions, data={}){
    const response = await fetch(url, {
        method: 'PUT',
        headers: headersOptions,
        body: JSON.stringify(data)
    });
    return response.json();
}

async function getData(url="", headersOptions, data={}){
    const response = await fetch(url, {
        method: 'GET',
        headers: headersOptions
    });
    return response.json();
}

function oneM2MaeBuilder(topic) {
    let object = {
        "m2m:ae": {
            "rn": topic,
            "api": "N" + topic,
            "rr": true,
            "srv": ["3"]
        }
    }
    return object
}


function containerBuilder(rn) {
    let object = {
        "m2m:cnt": {
            "rn": rn,
            "mni": 100
        }
    }
    return object
}

function contentInstanceBuilder(data) {
    let object = {
        "m2m:cin": {
            "con": data
        }
    }
    return object;
}

function groupBuilder() {
    let object = {

        "m2m:grp": {
  
            "mid": [
                "cse-in/Temp1/values/la"
            ],
            "mnm": 10,

            "rn": "valuesGroup2"
        }

    }
    return object;
}

function acpBuilder() {
    let object = {
        "m2m:acp": {
            "rn": "acp1",
            "pv": {
                "acr": [{ "acor": ["CAE1"], "acop": 63 }, { "acor": ["CAE2"], "acop": 63 }, { "acor": ["CAdmin"], "acop": 63 }]
            },
            "pvs": {
                "acr": [{ "acor": ["CAE1"], "acop": 63 }, { "acor": ["CAE2"], "acop": 63 }, { "acor": ["CAdmin"], "acop": 63 }]
            }
        }
    }
    return object;
}

function acpApplier(){
    let object = {
        "m2m:cnt": {
            "acpi": ["cse-in/acp1"]
        }
    }

    return object;
}
function registerAE(topic) {
    return postData(baseUrl, setHeaders("application/json;ty=2", "CAE2"), oneM2MaeBuilder("userApp"));
}

function registerAcp(){
    return postData(baseUrl, setHeaders("application/json;ty=1", "CAdmin"), acpBuilder());
}

function applyAcp(){
    return putData(baseUrl+"/Temp1/values", setHeaders("application/json", "CAE1"), acpApplier());
}
function registerGroup() {
    return postData(baseUrl + "/userApp", setHeaders("application/json;ty=9", "CAE2"), groupBuilder());
}

function getFopt(){
    return getData(baseUrl + "/userApp/valuesGroup2/fopt", setHeaders("application/json", "CAE2"));
}


/* 
{
    "m2m:sub": {
        "enc": {
            "net": [
                1,
                2,
                3,
                4
            ]
        },
        "nu": [
            "http://localhost:3000?ct=json"
        ],
        "rn": "sub1"
    }
}
*/




// {"op": 1, "to": "http://127.0.0.1:8080/cse-in", "fr": "CAE1", "rqi": "A1234", "ty": 2, "pc":
// {
//     "m2m:ae": {
//         "rn": "test",
//         "api": "Ntest",
//         "rr": true,
//         "srv": ["3"]
//     }
// }}



// OLD HTTP VERSION OF CODE

// */
// client.on('connect', function () {
//     client.subscribe("/CAV/latlng");
//     console.log("Client has subscribed successfully");
    
//     registerAE("CAV").then(data => {
//         console.log(data);
//         registerContainer("/CAV", "latlng").then(data => {
//             console.log(data)
//         });
      
//     }
//     );

// });

// function registerAE(ae) {
//     return postData(baseUrl, setHeaders("application/json;ty=2", "CAV"), oneM2MaeBuilder(ae));
// }

// function registerContainer(targetPath, resourceName) {
//     return postData(baseUrl + targetPath, setHeaders("application/json;ty=3", "CAV"), containerBuilder(resourceName));
// }

// function registerContentInstance(targetPath, data){
//     return postData(baseUrl+targetPath, setHeaders("application/json;ty=4", "CAV"), contentInstanceBuilder(data));
// }


// let requestHeaders;

// function setHeaders(contentType, originator) {

//     return {
//         'X-M2M-Origin': originator,
//         'X-M2M-RI': '1234',
//         'X-M2M-RVI': '3',
//         'Accept': 'application/json',
//         'Content-Type': contentType
//     }
// }




// async function postData(url = "", headersOptions, data = {}) {
   
//     const response = await fetch(url, {
//         method: 'POST',
//         headers: headersOptions,
//         body: JSON.stringify(data), 
//     });
//     return response.json(); 
// }


// OLD MQTT CODE AND OTHER EXPIREMENTS 
// client.subscribe('/oneM2M/resp/CAdmin/id-in/json');







// let subObject = {"op": 1, "to": "/id-in/cse-in/CAV/latlng", "fr": "CAdmin", "rqi": "1234", "ty": 23, "rvi": "3"}







// client.subscribe('/oneM2M/resp/CAE1/id-in/json');
// client.subscribe('/oneM2M/req/CAE1/id-in/json');
// client.subscribe('/oneM2M/req/id-in/+/json')


//     let object = {"op": 1, "to": "/id-in/cse-in", "fr": "CAE1", "rqi": "1234", "ty": 2, "rvi": "3", "pc":
//     {
//         "m2m:ae": {
//             "rn": "UserApp",
//             "api": "NUserApp",
//             "rr": true,
//             "srv": ["3"]
//         }
//     }}

    

// client.publish('/oneM2M/req/CAE1/id-in/json', JSON.stringify(object));

//     let hl = req.header('Content-Length');
//     let ct = req.header('Content-Type');
//     let rID = req.header('X-M2M-RI');

//     res.status(200).set('X-M2M-RSC', '2000').set('X-M2M-RI', rID).send();
//     io.emit('data', req.body["m2m:sgn"]["nev"]["rep"]["m2m:cin"]["con"]);







// let object3 = {"rsc": "2000"};

// client.publish('/oneM2M/req/CAE1/id-in/json', JSON.stringify(object2), (topic, payload) => {
//     client.publish('/oneM2M/resp/CAE1/+/json', JSON.stringify(object3));
// });


// client.on('message', (req, res) => {
//     let resp = JSON.parse(res);
//     console.log(JSON.parse(res));
//     if("pc" in resp ){
//         if("m2m:sgn" in resp["pc"]){
//             // let object3 = {"op": 5, "to": "/id-in/cse-in", "fr": "CAE2", "rqi": "1234", "rsc": "2000", "rvi": "3", "pc": {}}
          
            
//             // client.
//         console.log(JSON.parse(res));
//         }
//     }

//     // console.log(res.body);
//     // console.log(resp["vrq"]);
// })

// client.on('packetreceive', (req, res) =>{

// });

    // client.publish('/oneM2M/req/CAdmin/id-in/json', JSON.stringify(subObject));
    // client.subscribe('/oneM2M/req/id-in/+/json', (res) => {
        // client.on('message', (topic, res) => {
            // console.log(JSON.parse(res));
           
           
            // console.log(formattedD);
            // client.publish('/oneM2M/resp/id-in/CAdmin/json', formattedD);
            // io.emit('data',  response["pc"]["m2m:sgn"]["nev"]["rep"]["m2m:cin"]["con"]);
            // if("rep" in response){
            // client2.publish('data', response["pc"]["m2m:sgn"]["nev"]["rep"]["m2m:cin"]["con"])
            // }
        // })