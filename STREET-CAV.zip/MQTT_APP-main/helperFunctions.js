module.exports = {
    mqttPublish: function (client, topic, payload) {
        console.log(`Publish to topic: ${topic}`);
        console.log('Payload: ');
        console.log(JSON.parse(payload));
        client.publish(topic, payload);
    },

    mqttSubscribe: function (client, topic) {
        console.log(`Subscribing to: ${topic}`);
        client.subscribe(topic);
    },

    notificationVerification: function (response) {
        data = {
            'rsc': 2000,
            "rqi": response["rqi"],
            "rvi": response["rvi"]
        }
        formattedData = JSON.stringify(data);
        return formattedData;
    },

    buildMQTTObject: function (operationCode, destination, from, resourceType, content) {
        let object = { "op": operationCode, "to": destination, "fr": from, "rqi": "1234", "ty": resourceType, "rvi": "3", "pc": content };
        return object;

    },


    aeBuilder: function (topic) {
        let object = {
            "m2m:ae": {
                "rn": topic,
                "api": "N" + topic,
                "rr": true,
                "srv": ["3"]
            }
        }
        return object
    },


    containerBuilder: function (resourceName) {
        let object = {
            "m2m:cnt": {
                "acpi": ["cse-in/acp1"],
                "rn": resourceName,
                "mni": 100
            }
        }
        return object
    },

    contentInstanceBuilder: function (data) {
        let object = {
            "m2m:cin": {
                "con": data
            }
        }
        return object;
    },

    subscriptionBuilder: function (notificationAddress, resourceName) {
        let object = {
            "m2m:sub": {
                "enc": {
                    "net": [
                        1,
                        2,
                        3,
                        4
                    ]
                },
                "nu": [
                    notificationAddress
                ],
                "rn": resourceName
            }
        }
        return object;
    },

    accessControlPolicyBuilder: function() {
        let object = {
            "m2m:acp": {
                "rn": "acp1",
                "pv": {
                    "acr": [{ "acor": ["CIPE"], "acop": 63 }, { "acor": ["CV2X"], "acop": 63 }, { "acor": ["CAdmin"], "acop": 63 }]
                },
                "pvs": {
                    "acr": [{ "acor": ["CIPE"], "acop": 63 }, { "acor": ["CV2X"], "acop": 63 }, { "acor": ["CAdmin"], "acop": 63 }]
                }
            }
        }
        return object;
    }
}
