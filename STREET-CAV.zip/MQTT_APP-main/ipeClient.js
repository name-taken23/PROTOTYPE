let mqtt = require("mqtt");
let hF = require("./helperFunctions");
var client = mqtt.connect('mqtt://127.0.0.1:1883');
// let baseUrl = "http://127.0.0.1:8080/cse-in";

ipeResponseTopic = '/oneM2M/resp/CIPE/id-in/json';
ipeRequestTopic = '/oneM2M/req/CIPE/id-in/json';

client.on('connect', function () {

    /*
       ~~~ MQTT SUBSCRIPTION BLOCK ~~~

        THESE ARE NOT THE SAME AS THE CSE'S SUBSCRIPTIONS SERVICES
        These subscriptions are the TOPIC NAMES that are used in MQTT protocols to define when content should be sent to.

    */

    // Subscribe to the CAV's topics over MQTT
    client.subscribe("CAV/latlng");
    client.subscribe("CAV/response");
    // Subscribe to the CSE's responses to the IPE's requset over MQTT
    client.subscribe(ipeRequestTopic);
    // Subscribe to the notification URI we use for Subscription/Notify function of the CSE over MQTT
    client.subscribe('CAV/commandSub');

    /* ~~~ END OF MQTT SUBSCRIPTION BLOCK ~~~ */

    // Registers the CAV to the CSE as an AE (Application Entity)
    client.publish(ipeRequestTopic, JSON.stringify(hF.buildMQTTObject(1, "/id-in/cse-in", "CIPE", 2, hF.aeBuilder("CAV"))));
    
    // Registers a access control policy (allows for controlled access of resources) - this
    client.publish(ipeRequestTopic, JSON.stringify(hF.buildMQTTObject(1, "/id-in/cse-in", "CIPE", 1, hF.accessControlPolicyBuilder())));

    // Time out for synchronous creation - Cannot create resources on a resource if the prior resource doesn't exist yet
    setTimeout(()=> {
        /*
            Note: 
            "/id-in/cse-in/CAV" - This path exists because of the AE registration prior to these requests - we are saying "create this resource at this path"
            These requests are sent to the "main" entry point of the MQTT protocol of the CSE, i.e: ipeRequestTopic = "/oneM2M/req/CIPE/id-in/json" || "/oneM2M/req/+/id-in/json"
        */


        // Registers a container for the LATLNG of the CAV
        client.publish(ipeRequestTopic, JSON.stringify(hF.buildMQTTObject(1, "/id-in/cse-in/CAV", "CIPE", 3, hF.containerBuilder("latlng"))));

        // Registers a container for COMMANDS from the front end TO the CAV
        client.publish(ipeRequestTopic, JSON.stringify(hF.buildMQTTObject(1, "/id-in/cse-in/CAV", "CIPE", 3, hF.containerBuilder("COMMAND"))));

        // Registers a container for RESPONSES from the CAV
        client.publish(ipeRequestTopic, JSON.stringify(hF.buildMQTTObject(1, "/id-in/cse-in/CAV", "CIPE", 3, hF.containerBuilder("response"))));
        setTimeout(()=> {

            // Once the containers (which hold the data) of the CAV have been registered, then we create a subscription to the command container that the CAV created
            // This is going to be our "input" subscription which we "listen" too, i.e the CSE will send notifications to this URI -> "mqtt://127.0.0.1:1883/CAV/commandSub" 
            /*
            Note: The IPE subscribed to the topic name (over MQTT) earlier on line 25 -> "CAV/commandSub" -
            To subscribe with the CSE's functionality, a verification response must be sent on subscription creation, hence subscribing via MQTT to the topic, before we subscribe
            using the CSE's common services functions
            */

            hF.mqttPublish(client, '/oneM2M/req/CIPE/id-in/json', JSON.stringify(hF.buildMQTTObject(1, "/id-in/cse-in/CAV/COMMAND", "CIPE", 23, hF.subscriptionBuilder("mqtt://127.0.0.1:1883/CAV/commandSub","commandSub"))));  
        }, 500)
    }, 500)

});

// Message handling of MQTT clients - Anytime a message is sent to our subscribed topics (which we subscribed too earlier on lines 20-23), this function is triggered
// We recieve the Topic and the Payload
client.on('message', function(topic, payload) {
    console.log("Response Topic: " + topic)
    response = JSON.parse(payload);
    console.log("Response message: ");
    console.log(response);

    // This if block checks the response content of a message
    // If the response message content meets the CSE subscription notification verification criteria, a response is sent back to the CSE to verify the request
    if(response.pc && response.pc["m2m:sgn"] && response.pc["m2m:sgn"]["vrq"]){
        hF.mqttPublish(client, '/oneM2M/resp/id-in/CAdmin/json', hF.notificationVerification(response));
    } 

    // This if block triggers on the MQTT topic "CAV/latlng"
    // If a message is sent to this topic (this would be a message from the CAV, intended path is the CSE) ->
    // A request is then sent to the CSE to create a content instance resource containing the content (payload of the MQTT message) sent by the CAV under the "latlng" container resource
    if(topic === "CAV/latlng"){
        client.publish(ipeRequestTopic, JSON.stringify(hF.buildMQTTObject(1, "/id-in/cse-in/CAV/latlng", "CIPE", 4, hF.contentInstanceBuilder(JSON.parse(payload).lat + "," + JSON.parse(payload).lng))));
    }

    // This if block triggers on the MQTT topic "CAV/response"
    // If a message is sent to this topic (this would be a message from the CAV, intended path is the CSE) ->
    // A request is then sent to the CSE to create a content instance resource containing the content (payload of the MQTT message) sent by the CAV under the "response" container resource
    if(topic === "CAV/response"){
        client.publish(ipeRequestTopic, JSON.stringify(hF.buildMQTTObject(1, "/id-in/cse-in/CAV/response", "CIPE", 4, hF.contentInstanceBuilder(JSON.stringify(JSON.parse(payload))))));
    }

    // This if block triggers on the MQTT topic "CAV/commandSub" - this is the MQTT topic we setup for notifications from the CSE
    // IF a message is sent to this topic (this would be a message from the CSE, intended path is the CAV) ->
    // A message is then published to the topic "CAV/command" containing the response content of the notification (via the subscribe/notify function of the CSE)
    if(topic === "CAV/commandSub"){
        if(response.pc && response.pc["m2m:sgn"] && response.pc["m2m:sgn"]["nev"] && response.pc["m2m:sgn"]["nev"]["rep"] && response.pc["m2m:sgn"]["nev"]["rep"]["m2m:cin"]){
            client.publish('CAV/command', response["pc"]["m2m:sgn"]["nev"]["rep"]["m2m:cin"]["con"]);
        }
    }

})

