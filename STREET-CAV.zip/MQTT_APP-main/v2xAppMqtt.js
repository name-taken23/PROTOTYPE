let mqtt = require("mqtt");
let hF = require("./helperFunctions")
//Connects to MQTT broker
var client = mqtt.connect('mqtt://127.0.0.1:1883');
//Connects to MQTT broker using WS protocol (prefix of url) - Front end data feed only allows for WS connection because of browser limitations
var client2 = mqtt.connect("ws://127.0.0.1:1884")




client.on("connect", function () {

    // Subscribe to REQUESTS from the CSE to the V2X application - These topics are used for the subscription verification requests and further messages
    hF.mqttSubscribe(client, 'v2xApp/data');
    hF.mqttSubscribe(client, 'v2xApp/response');

    // Subscribe to RESPONSES from CSE to the CV2X identifier
    hF.mqttSubscribe(client, '/oneM2M/resp/CV2X/Admin/id-in/json');

    // Subscribes to REQUESTS from the front end over MQTT WS protocol
    // Note: This a 2nd MQTT client we are using on a different port
    hF.mqttSubscribe(client2, 'frontend/command');

    // Setup the subscription resource in CSE - send the subscription object
    // Note: The URI's postfix the topic name we defined and subscribed to earlier
    hF.mqttPublish(client, '/oneM2M/req/CV2X/id-in/json', JSON.stringify(hF.buildMQTTObject(1, "/id-in/cse-in/CAV/latlng", "CV2X", 23, hF.subscriptionBuilder("mqtt://127.0.0.1:1883/v2xApp/data","dataSub"))));
    hF.mqttPublish(client, '/oneM2M/req/CV2X/id-in/json', JSON.stringify(hF.buildMQTTObject(1, "/id-in/cse-in/CAV/response", "CV2X", 23, hF.subscriptionBuilder("mqtt://127.0.0.1:1883/v2xApp/response","responseSub"))));
    
});

    
// Message handling of MQTT clients - Anytime a message is sent to our subscribed topics this function is triggered
// We recieve the Topic and the Payload
client.on('message', (topic, res) =>{
    console.log("Response Topic: " + topic)
    response = JSON.parse(res);
    console.log("Response message: ");
    console.log(response);

    // This if block checks the response content of a message
    // If the response message content meets the CSE subscription notification verification criteria, a response is sent back to the CSE to verify the request
    // Note: In this example, we have requested 2 subscription resources in the CSE as defined by earlier statements - This block responds to all CSE subscription verification requests
    if(response.pc && response.pc["m2m:sgn"] && response.pc["m2m:sgn"]["vrq"]){
        hF.mqttPublish(client, '/oneM2M/resp/id-in/CV2X/json', hF.notificationVerification(response));
    } 

    // This if block triggers on the MQTT topic "v2xApp/data" - this is a MQTT topic we setup for notifications from the CSE
    // If a message is sent to this topic (this would be a message from the CSE, intended path is the V2X App) ->
    // The V2X app currently "forwards", i.e publishes over MQTT Websocket, to the front end, the content in the CSE notification object
    if(topic === 'v2xApp/data') {
        if(response.pc && response.pc["m2m:sgn"] && response.pc["m2m:sgn"]["nev"] && response.pc["m2m:sgn"]["nev"]["rep"] && response.pc["m2m:sgn"]["nev"]["rep"]["m2m:cin"]){
            client2.publish('data/chart', response["pc"]["m2m:sgn"]["nev"]["rep"]["m2m:cin"]["con"].toString());
        }
    }

    // This if block triggers on the MQTT topic "v2xApp/response" - this is a MQTT topic we setup for notifications from the CSE
    // If a message is sent to this topic (this would be a message from the CSE, intended path is the V2X App) ->
    // The V2X app currently "forwards", i.e publishes over MQTT Websocket, to the front end, the content in the CSE notification object
    if(topic === 'v2xApp/response') {
        if(response.pc && response.pc["m2m:sgn"] && response.pc["m2m:sgn"]["nev"] && response.pc["m2m:sgn"]["nev"]["rep"] && response.pc["m2m:sgn"]["nev"]["rep"]["m2m:cin"]){
            client2.publish('data/response', response["pc"]["m2m:sgn"]["nev"]["rep"]["m2m:cin"]["con"]);
        }
    }

})

// Message handling of MQTT clients - Anytime a message is sent to our subscribed topics this function is triggered
// We recieve the Topic and the Payload
// Note this is a 2nd MQTT client (client2) that is connecting to a different port using websockets over MQTT - we 
client2.on('message', (topic, res) => {
    console.log("Response Topic: " + topic)
    response = JSON.parse(res);
    console.log("Response message: ");
    console.log(response);

    // This if block triggers on the MQTT topic "frontend/command" 
    // If a message is sent to this topic (this would be a message from the FrontEnd, intended path is the V2X App onto the CSE and so forth) ->
    // A request to create a new content instance under the command container in the CSE is published to a topic that the CSE is subscribed too
    // Note: Eventually the CAV will recieve this command, as the IPE is subscribed to this container using the CSE's common service functions
    if(topic === 'frontend/command'){
        hF.mqttPublish(client, '/oneM2M/req/CV2X/id-in/json', JSON.stringify(hF.buildMQTTObject(1, "/id-in/cse-in/CAV/COMMAND", "CV2X", 4, hF.contentInstanceBuilder(response["message"]))));
     }
})


