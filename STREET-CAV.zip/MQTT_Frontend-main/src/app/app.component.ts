import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
// import { V2xService } from './v2x.service';
import * as socketIo from 'socket.io-client';
import { Observable } from 'rxjs';
import { Chart, registerables } from 'chart.js';
import mqtt from 'mqtt';
import * as L from 'leaflet'
import { control, icon, circle, latLng, Layer, marker, Marker, tileLayer } from 'leaflet';
Chart.register(...registerables);

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'mqtt-frontend';
  labels: any[] = [];
  dataLat: any[] = [];
  dataLng: any[] = [];
  chart: any;
  ctx: any;
  map!: L.Map;
  tiles: any;
  marker!: L.Marker;
  circle!: L.Circle;
  responseMessage: string = "";
  client = mqtt.connect('ws://127.0.0.1:1884');
  constructor() {

  }

  ngOnInit(): void {
    setTimeout(this.createChart, 1);
    setTimeout(this.createMap, 1);

    this.mqttSub();
    this.client.on('connect', () => {
      this.client.subscribe('data/+');
    })
  }

  /* MQTT */
  // Similarly to the V2X platform, the front end follows a similar process for it's behaviour.
  // The core difference being it doesn't do any (de)/serialization of CSE data structures, rather publishes content over MQTT WS to the V2X app and recieves it in JSON format - 
  // Note: It still has to parse data out of byte format into string/json objects
  mqttSub() {
    let i = 0;
    this.client.on('message', (topic, payload) => {
      if (topic === 'data/chart') {
        let dataString = payload.toString().split(",");
        this.dataLat.push(dataString[0]);
        this.dataLng.push(dataString[1]);
        this.labels.push("Reading: " + i++);
        this.marker.setLatLng([parseFloat(dataString[0]), parseFloat(dataString[1])]);
        this.circle.setLatLng([parseFloat(dataString[0]), parseFloat(dataString[1])]);
        console.log(dataString);
        this.chart.update();
      }

      if(topic === 'data/response'){
        this.responseMessage = payload.toString();
      }    
    })
  }

  stopCav() {
    this.client.publish('frontend/command', JSON.stringify({ "message": "stop" }));
  }

  startCav() {
    this.client.publish('frontend/command', JSON.stringify({ "message": "start" }));
  }

  //   mqttSub2() {
  //     let client = mqtt.connect('ws://127.0.0.1:1884')
  //     client.on("connect", function () {

  //       client.subscribe('/oneM2M/req/id-in/+/json', (res) => {
  //           client.on('message', (topic, res) => {
  //               console.log(JSON.parse(res.toString()));
  //               let response = JSON.parse(res.toString());
  //               let data = {

  //                   'rsc': 2000,
  //                   "rqi": response["rqi"],
  //                   "rvi": response["rvi"]

  //               }
  //               let formattedD = JSON.stringify(data);
  //               console.log(formattedD);
  //               client.publish('/oneM2M/resp/id-in/CAdmin/json', formattedD);
  //               // io.emit('data',  response["pc"]["m2m:sgn"]["nev"]["rep"]["m2m:cin"]["con"]);
  //               // client2.publish('data', response["pc"]["m2m:sgn"]["nev"]["rep"]["m2m:cin"]["con"])
  //           })
  //       });
  //   })
  // }


  createChart = () => {
    this.ctx = document.getElementById("myChart") as HTMLCanvasElement;
    this.chart = new Chart(this.ctx, {
      type: 'line',
      data: {
        labels: this.labels,
        datasets: [{
          label: 'Latitude',
          data: this.dataLat,
          yAxisID: 'y',
        },

        ]
      }
    })
  }


  createMap = () => {
    var map = L.map('map').setView([53.3409, -6.2625], 13);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);
   this.marker = L.marker([53.3409, -6.2625]).addTo(map);
    this.circle = L.circle([53.3409, -6.2625], {
      color: 'red',
      fillColor: '#f03',
      fillOpacity: 0.5,
      radius: 500
    }).addTo(map);
  }

  /* SOCKET */

  // private socket = socketIo.io("ws://localhost:3001");

  // getMessages() {
  // let i = 0;
  //  this.socket.on('data', (data) => {
  //       this.data.push(data);
  //       this.labels.push("Reading: " + i++);
  //       console.log(data);
  //       this.chart.update();
  //     });
  //   }
}
